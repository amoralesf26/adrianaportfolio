import type { NextConfig } from 'next';

const repository = process.env.GITHUB_REPOSITORY?.split('/')[1] ?? '';
const isProjectPage = process.env.GITHUB_ACTIONS === 'true' && !repository.endsWith('.github.io');
const basePath = isProjectPage ? `/${repository}` : '';

const nextConfig: NextConfig = {
  output: 'export',
  basePath,
  assetPrefix: basePath || undefined,
};

export default nextConfig;
